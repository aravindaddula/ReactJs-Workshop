import React, { Component} from 'react';
import ReactDOM from 'react-dom';


class MainApp extends Component{
    state = {
       power : 10
       
    }
    increasePower = ()=>{
        this.setState({
            power : this.state.power +1
        })
    }
    decreasePower = ()=>{
        this.setState({
            power : this.state.power - 1
        })
    }
   render(){
  return <div>
      <h1>who is the hero</h1>
      <h2>{this.state.power} </h2>
      <h2>{(this.state.power < 10) ? "Hero is Weak" : "Hero is Strong" } </h2>
      <button onClick={this.increasePower}>Increase Power </button>
      <button onClick={this.decreasePower}>decrease Power </button>
  </div>
   }   
} 
ReactDOM.render( <MainApp/> , document.getElementById("root") );