import React, { Component} from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
     conf = {
         power : 0
     }
     increasePower = ()=>{         
             this.conf.power = this.conf.power + 1 ;
             console.log(this.conf.power)
             this.forceUpdate();
            }
     
    render(){
        return <div>
                <h1>Welcome to My Life</h1>
                <h1> { this.conf.power }</h1>
                <button onClick = { this.increasePower } >Click </button>
                          
             </div>
    }
} 
ReactDOM.render( <MainApp/> , document.getElementById("root") );