import React, { Component} from 'react';
import ReactDOM from 'react-dom';
import ChildComp from './components/child.component';

class MainApp extends Component{
    state = {
        message :'' ,
        power : 0
    }
    ipref=React.createRef()
    changeMessage = ()=>{
        this.setState({
           message : this.ipref.current.value
        })
    }

    changePower=(val)=>{
        this.setState({
            power : val
        })
    }

    render(){
        return <div>
                <h1>Main Application</h1>
                <h2> Parent message : {this.state.message} </h2>
                <h2>{ this.state.power } </h2>
                <input ref={this.ipref} />
                <button onClick={this.changeMessage } > set message </button>
                
                <ChildComp chp={this.changePower} toChildMsg={this.state.message} />      
             </div>
    }
} 
ReactDOM.render( <MainApp/> , document.getElementById("root") );