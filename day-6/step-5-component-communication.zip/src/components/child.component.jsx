import React, { Component} from 'react';
import ReactDOM from 'react-dom';

class ChildComp extends Component{
    
    render(){
        return <div>
                <h1>Child Component </h1>
                <h2> Message from parent is : { this.props.toChildMsg } </h2>
                <button onClick={this.props.chp} >Change power from Child</button>
                <input 
                type="range" min="5" max="100" step="5"
                onInput={ (event)=>{
                    this.props.chp( Number(event.target.value))
                } }
                />
                          
             </div>
    }
} 
ReactDOM.render( <ChildComp/> , document.getElementById("root") );

export default ChildComp