import React, { Component} from 'react';
import ReactDOM from 'react-dom';
  
class ChildApp extends Component{
   
    render(){
        return <div>
           <h1>Get Counter</h1>
           <h1> { this.props.getVersion } </h1>
           
        </div>;
    }
}
class MainApp extends Component{
     state={
         version:0
     }
     clickhandler = ()=>{
         this.setState({
             version:this.state.version + 1 
            })
     }
    render(){
        return <div>
                <h1>Welcome to My Life</h1>
                <button onClick={this.clickhandler.bind(this)} >Click </button>
                <ChildApp getVersion={this.state.version} >0</ChildApp>
                          
             </div>
    }
} 
ReactDOM.render( <MainApp/> , document.getElementById("root") );