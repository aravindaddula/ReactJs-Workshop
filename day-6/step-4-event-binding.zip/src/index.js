import React, { Component} from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
     state = {
         power : 0
     }
     
     increasePower = ()=>{
         this.setState( {
            power : Number(this.state.power +1 ) 
         })
     }     
          
     increasePowerRange = (event)=>{
        this.setState( {
           power : Number(event.target.value)
        })
    }        
    iref=React.createRef()

    setPowerFromInput = ()=>{
        this.setState( {
           power : Number(this.iref.current.value)
        })
    }   
    setPowerTo50 = ()=>{
        this.setState( {
           power : 50
        })
    }      
     
    render(){
        return <div>
                <h1>Welcome to My Life</h1>
                <h1> { this.state.power }</h1>
                <button onClick = { this.increasePower } >Click </button>
                <br/>
                <input onInput={this.increasePowerRange } type="range" />
                <br/>
                <input ref={ this.iref} type="number" />
                <button onClick={this.setPowerFromInput} >set value from input </button>
                <br/>
                <button onClick={this.setPowerTo50} >set value To 50 </button>

                          
             </div>
    }
} 
ReactDOM.render( <MainApp/> , document.getElementById("root") );