import React, { Component, Fragment} from 'react';
import ReactDOM from 'react-dom';
  
class MainApp extends Component{
    render(){
        return <Fragment>
            <h1 className="box">Welcome to my Life 3</h1>
            <h1 className="box">Welcome to my Life 1</h1>
            <h1 className="box">Welcome to my Life 4</h1>
            <h1 className="box">Welcome to my Life 2</h1>
            <input/><br/>
            <input/>
        </Fragment> ;
    }
} 
 
ReactDOM.render(<MainApp/>, document.getElementById("root"));

