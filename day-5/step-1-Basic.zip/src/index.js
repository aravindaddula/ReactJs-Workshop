import React, { Component } from 'react';
import ReactDOM from 'react-dom';
  
class Item extends Component{
    render(){
        return <li>List item { this.props.children }</li>
    }
}
class FirstComp extends Component{
    render(){
        return <div>
                <h1>My First React App </h1>
                    <ol>
                        <Item>1</Item>
                        <Item>2</Item>
                        <Item>3</Item>
                        <Item>4</Item>
                        <Item>5</Item>
                    </ol>
                    <ul>
                        <Item>1</Item>
                        <Item>2</Item>
                        <Item>3</Item>
                        <Item>4</Item>
                        <Item>5</Item>
                    </ul>
            </div>
    }
}
 
 
ReactDOM.render(<FirstComp/>, document.getElementById("root"));

// function newFunction() {
//     { /* <h1 title="" lang="" class="" onclick="">welcome to your life</h1> */ }
// }
