import React, { Component} from 'react';
import ReactDOM from 'react-dom';
  
class List extends Component{
    render(){
        return <div>
            <ul>
                { <h3> { this.props.title }  </h3> }
             { this.props.heroList.map(val => <li> {val} </li> )}
            </ul>
        </div>;
    }
}

class MainApp extends Component{
     avengers = [ 'Ironman','superman','Batman' ] ;
     league = [ 'Ironman','superman','Batman' ]
    render(){
        return <div>
                <h1>Welcome to My Life</h1>
                <List title="Avengers" heroList={this.avengers} />
                <List title="Justice League " heroList={this.league} />
             </div>
    }
} 
ReactDOM.render( <MainApp/> , document.getElementById("root") );
 

