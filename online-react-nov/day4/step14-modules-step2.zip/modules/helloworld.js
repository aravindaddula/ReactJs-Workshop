export function helloWorld(){
    console.log("Welcome to your life");
};
