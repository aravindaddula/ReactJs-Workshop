class Person{
    message = 'default value';
    constructor(nmessage){
        this.message = nmessage+" from person";
    }
};

class Person1{
    message = 'default value';
    constructor(nmessage){
        this.message = nmessage+"  from person 1";
    }
};

class Person2{
    message = 'default value';
    constructor(nmessage){
        this.message = nmessage+"  from person 2";
    }
};

// export { Person, Person1, Person2 };
export default Person;
export { Person1, Person2 };