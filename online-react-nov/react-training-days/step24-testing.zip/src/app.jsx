import { Component } from "react";

class HeroComp extends Component{
    state = {
        power : 5,
        title : 'batman'
    }
    render(){
        return <div className="container">
            <h2>Power is : { this.state.power }</h2>
            <h2>Title is : { this.state.title }</h2>
        </div>
    }
}

export default HeroComp;