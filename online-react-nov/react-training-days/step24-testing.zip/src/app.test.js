import HeroComp from "./app";

describe("Test Hero Component",()=>{
    let herocomp = null;
    describe("Testing for Power",()=>{
       beforeEach(()=>{
           herocomp = new HeroComp();
       })
       it("Should have Power",()=>{
           expect(herocomp.state.power).toBeDefined()
        })
        it("Should have Power = 5",()=>{
            expect(herocomp.state.power).toBe(5)
        })
        afterEach(()=>{
            herocomp = null;
        })
    })
    describe("Testing for Title",()=>{
       beforeEach(()=>{
           herocomp = new HeroComp();
       })
        it("Should have Title",()=>{
            expect(herocomp.state.title).toBeDefined()
        })
        it("Should have Title as batman",()=>{
            expect(herocomp.state.title).toBe('batman')
        })
        afterEach(()=>{
            herocomp = null;
        })
   })
})