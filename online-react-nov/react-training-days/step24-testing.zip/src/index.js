import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import HeroComp from './app';


class MainApp extends Component{
    render(){
        return <div className='container'>
                <h1> React Testing 101 </h1>
                <HeroComp/>
             </div> 
    }
}


ReactDOM.render(<MainApp/>, document.getElementById("root"));