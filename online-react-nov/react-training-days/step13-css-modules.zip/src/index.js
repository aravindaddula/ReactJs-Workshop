import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import client from  "./client.module.css";
import "./mystyle.css";

class MainApp extends Component{
    mystyle = {backgroundColor : "plum", padding: "10px"};
    render(){
        return <div className="container">
                <h1> Welcome to your life </h1>
                <p style={ this.mystyle }>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Et ducimus velit ad culpa, beatae iusto quos eius quo maiores ut voluptatem ipsam vitae laboriosam, esse enim officiis, dolore hic tempore.
                </p>

                <p className="box">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Culpa, deleniti. Quia est non quibusdam, maiores odio quae pariatur. Ipsa, fuga facere? Nemo minima voluptatum voluptas, voluptates nisi exercitationem praesentium earum?
                </p>

                <p>
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Voluptatibus atque mollitia obcaecati nam totam quasi earum, quia inventore quibusdam quis dolorum perspiciatis eveniet vero, unde tempore nobis! Itaque, et magnam.
                </p>
                <hr/>
                <p className={ client.box }>
                    Client CSS 
                    <br/>
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam expedita illum at alias consequatur. Asperiores fugiat id ducimus, nihil, dicta ut quia est consequatur deleniti et labore in maiores? Assumenda?
                </p>
                <hr/>
                <p>
                    Lorem ipsum dolor sit amet consectetur, adipisicing elit. Voluptatibus atque mollitia obcaecati nam totam quasi earum, quia inventore quibusdam quis dolorum perspiciatis eveniet vero, unde tempore nobis! Itaque, et magnam.
                </p>

                <p className="box">
                    Lorem ipsum dolor sit amet consectetur adipisicing elit. Nam expedita illum at alias consequatur. Asperiores fugiat id ducimus, nihil, dicta ut quia est consequatur deleniti et labore in maiores? Assumenda?
                </p>
               </div>
    }
}


ReactDOM.render(<MainApp/>, document.getElementById("root"));