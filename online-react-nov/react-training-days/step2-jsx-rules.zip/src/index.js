import React, { Component, Fragment } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
    render(){
        return <div style={ { border : "2px solid red", backgroundColor : 'papayawhip'} }>
                    <h1 className="box"> Welcome to your life </h1>
                    <h1 className="box"> Welcome to your life </h1>
                    <h1 className="box"> Welcome to your life </h1>
                    <h1 className="box"> Welcome to your life </h1>
                    <input defaultValue="hello there"/>
                    <br/>
                    <input/>
                    <hr/>
                </div>
    }
}


ReactDOM.render(<MainApp/>, document.getElementById("root"));