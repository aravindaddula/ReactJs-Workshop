import React, { Component } from 'react';
import ReactDOM from 'react-dom';

/* let elm = document.createElement("h1");
    elm.innerHTML = "Welcome to your life";
    elm.setAttribute("title", "My Heading"); */

{/* <h1 title="" lang="" class="" onclick="">welcome to your life</h1> */}

// let elm = React.createElement("h1",{title:"my heading"},"welcome to your life !!!");

/* let elm = React.createElement("ol",null,
React.createElement("li",null, "List Item 1"),
React.createElement("li",null, "List Item 2"),
React.createElement("li",null, "List Item 3"),
React.createElement("li",null, "List Item 4"),
React.createElement("li",null, "List Item 5")
); */


// Element
/* let elm = <div>
                <h1>My First React App </h1>
                    <ol>
                        <li>List item 1</li>
                        <li>List item 2</li>
                        <li>List item 3</li>
                        <li>List item 4</li>
                        <li>List item 5</li>
                    </ol>
                    <ul>
                        <li>List item 1</li>
                        <li>List item 2</li>
                        <li>List item 3</li>
                        <li>List item 4</li>
                        <li>List item 5</li>
                    </ul>
             </div>; */

/* function Item(){
    return <li>List item 1</li>
} */
/*  function FirstComp(){
     return <div>
            <h1>My First React App </h1>
                <ol>
                    <Item/>
                    <Item/>
                    <Item/>
                    <Item/>
                    <Item/>
                    <Item/>
                </ol>
                <ul>
                    <Item/>
                    <Item/>
                    <Item/>
                    <Item/>
                    <Item/>
                    <Item/>
                </ul>
        </div>
 }
 */

class Item extends Component{
    render(){
        return <li>List item { this.props.children }</li>
    }
}
class FirstComp extends Component{
    render(){
        return <div>
                <h1>My First React App </h1>
                    <ol>
                        <Item>1</Item>
                        <Item>2</Item>
                        <Item>3</Item>
                        <Item>4</Item>
                        <Item>5</Item>
                    </ol>
                    <ul>
                        <Item>1</Item>
                        <Item>2</Item>
                        <Item>3</Item>
                        <Item>4</Item>
                        <Item>5</Item>
                    </ul>
            </div>
    }
}


ReactDOM.render(<FirstComp/>, document.getElementById("root"));