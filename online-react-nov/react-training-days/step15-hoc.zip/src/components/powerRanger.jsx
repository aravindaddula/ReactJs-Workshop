import React, { Component } from 'react';
import WithPower from '../hoc/withPower';

class PowerRanger extends Component{

    render(){
        return <div>
                <h1> Power Ranger </h1>
                <h2>Power : { this.props.power }</h2>
                <h3>{ this.props.title }</h3>
                <input type="range" onChange={ this.props.asnPower }/>
            </div>
    }
}

export default WithPower(PowerRanger);