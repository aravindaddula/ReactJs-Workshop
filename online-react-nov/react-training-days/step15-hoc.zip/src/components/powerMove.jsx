import React, { Component } from 'react';
import WithPower from '../hoc/withPower';

class PowerMove extends Component{
    render(){
        return <div>
                <h1> Power Move </h1>
                <h2>Power : { this.props.power }</h2>
                <h3>{ this.props.title }</h3>
                <div style={ { width : '200px',textAlign:"center", lineHeight: '50px', height : '50px', backgroundColor : "darkgray", color : "papayawhip"} } onMouseMove={ this.props.incPower }>Increase Power</div>
            </div>
    }
}

export default WithPower(PowerMove);