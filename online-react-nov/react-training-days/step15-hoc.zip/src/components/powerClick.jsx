import React, { Component } from 'react';
import WithPower from '../hoc/withPower';

class PowerClick extends Component{
    
    render(){
        return <div>
                <h1> Power Click </h1>
                <h2>Power : { this.props.power }</h2>
                <h3>{ this.props.title }</h3>
                <button onClick={ this.props.incPower }>Increase Power</button>
            </div>
    }
}

export default WithPower(PowerClick);