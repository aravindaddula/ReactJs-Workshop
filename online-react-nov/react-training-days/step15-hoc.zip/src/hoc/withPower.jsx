import { Component } from "react";

let WithPower = (OriginalComponent) => {
    class NewComp extends Component{
        state = {
            power : 0
        }
        increasePower = ()=>{
            this.setState({
                power : this.state.power + 1
            })
        }
        assignPower = (evt)=>{
            this.setState({
                power : Number(evt.target.value)
            })
        }
        render(){
            return <OriginalComponent asnPower={ this.assignPower } incPower={ this.increasePower } power={ this.state.power } title="Hello from HOC"/>
        }
    };

    return NewComp;
}

export default WithPower;