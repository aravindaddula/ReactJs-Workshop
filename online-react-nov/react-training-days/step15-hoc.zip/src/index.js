import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import PowerClick from './components/powerClick';
import PowerMove from './components/powerMove';
import PowerRanger from './components/powerRanger';

class MainApp extends Component{
    render(){
        return <div className="container">
                <h1> Welcome to your life </h1>
                <hr/>
                <PowerClick/>
                <PowerRanger/>
                <PowerMove/>
              </div>
    }
}


ReactDOM.render(<MainApp/>, document.getElementById("root"));