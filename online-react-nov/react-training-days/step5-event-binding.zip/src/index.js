import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class ChildComp extends Component{
    render(){
        return <div>
                <h1> Child Component </h1>
                <h2>{ this.props.version }</h2>
               </div>
    }
}
class MainApp extends Component{
    state = {
        version : 0
    }
/*     constructor(){
        super();
        this.clickHandler = this.clickHandler.bind(this);
    } */
    clickHandler = () => {
        this.setState({ 
            version : this.state.version + 1 
        });
    }
    render(){
        return <div>
                <h1> Welcome to your life </h1>
{/*             <button onClick={ this.clickHandler.bind(this) }> Increase Version </button>
                <button onClick={ this.clickHandler.bind(this) }> Increase Version </button> */}
                <button onClick={ this.clickHandler }> Increase Version </button>
                <hr/>
                <ChildComp version={this.state.version} />
                <ChildComp version={this.state.version} />
                <ChildComp version={this.state.version} />
                <ChildComp version={this.state.version} />
               </div>
    }
}


ReactDOM.render(<MainApp/>, document.getElementById("root"));