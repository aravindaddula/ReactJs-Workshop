import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import HeroComp from './components/hero.component';
import { Provider } from 'react-redux';
import store from './redux/store';
import HeroHookComp from './components/hero.hook.component';

class MainApp extends Component{
    render(){
        return <div className='container'>
                <h1> React Redux </h1>
                <Provider store={ store }>
                      <HeroComp/>
                      <hr/>
                      <HeroHookComp/>
                </Provider>
             </div> 
    }
}


ReactDOM.render(<MainApp/>, document.getElementById("root"));