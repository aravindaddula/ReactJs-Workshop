import { useDispatch, useSelector } from "react-redux";
import addHero from "../redux";

let HeroHookComp = ()=>{
    const numberOfHeroes = useSelector(state => state.numberOfHeroes);
    const dispatch = useDispatch();

    return <div>
            <h2>Avengers Enrollment Program with Hooks</h2>
            <h2>Number of Avengers : { numberOfHeroes }</h2>
            <button onClick={ ()=> dispatch( addHero() ) }>Add Avenger</button>
        </div>

}

export default HeroHookComp;