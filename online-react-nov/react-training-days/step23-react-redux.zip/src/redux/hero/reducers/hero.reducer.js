import { ADD_HERO } from "../type/hero.type";

const defaultState = {
    numberOfHeroes : 0
}

const heroReducer = ( state = defaultState, action)=>{
    switch(action.type){
        case ADD_HERO : return { 
            ...state,
            numberOfHeroes : state.numberOfHeroes + 1
         }
         default : return state
    }
}

export default heroReducer;