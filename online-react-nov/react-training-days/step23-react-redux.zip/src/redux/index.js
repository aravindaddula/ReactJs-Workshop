import addHero from './hero/actions/hero.action';

export default addHero;