import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
    state = {
        power : 0
    }
    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
    increasePowerFromRange = (evt)=>{
        this.setState({
            power : Number(evt.target.value)
        })
    }
    ipref = React.createRef();
    setPowerFromInput = ()=>{
        this.setState({
            power : Number(this.ipref.current.value)
        })
    }
    setPowerTo50 = ()=>{
        this.setState({
            power : 50
        })
    }
    render(){
        return <div>
                <h1> Welcome to your life </h1>
                <h2>Power : { this.state.power }</h2>
                <button onClick={ this.increasePower }>Increase Power</button>
                <br/>
                <input onInput={ this.increasePowerFromRange } type="range"/>
                <br/>
                <input ref={ this.ipref } type="number"/>
                <button onClick={ this.setPowerFromInput }>Set value from the input</button>
                <br/>
                <button onClick={ this.setPowerTo50 }>Set value to 50</button>
            </div>
    }
}


ReactDOM.render(<MainApp/>, document.getElementById("root"));