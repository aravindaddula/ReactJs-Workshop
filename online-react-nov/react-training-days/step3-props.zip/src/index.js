import React, { Component } from 'react';
import ReactDOM from 'react-dom';

/* class ListItem extends Component{
    render(){
        return <li>{ this.props.title }</li>
    }
} */

class List extends Component{
    render(){
        return <div>
                    <h2> { this.props.title } </h2>
                    <ol> { this.props.herolist.map( (val, idx) => <li key={idx}>{val}</li> )} </ol>
                </div>
    }
}
class ObjList extends Component{
    render(){
        return <div>
                    <h2> { this.props.title } </h2>
                    <ol> { this.props.herolist.map( (val, idx) => <li key={idx}>{val.title}</li> )} </ol>
                </div>
    }
}

class MainApp extends Component{
   /*  avengers = ['Ironman', 'Hulk', 'Scarlet','Captain america', 'Antman'];
    justiceleague = ['Batman','Superman','Aquaman','Flash'];
    indicHeroes = ['Shaktiman','Krish']; */
    avengers = [{ title : "Ironman", power : 7 },{ title : "Hulk", power : 8 }];
    justiceleague = ['Batman','Superman','Aquaman','Flash'];
    indicHeroes = ['Shaktiman','Krish'];
    render(){
        return <div>
                    <h1> Welcome to your life </h1>
                    <List title="Justice League" herolist={ this.justiceleague }/>
                    <List title="Indic Heroes" herolist={ this.indicHeroes }/>
                    <hr/>
                    <ObjList herolist={ this.avengers }/>
                </div>
    }
}


ReactDOM.render(<MainApp/>, document.getElementById("root"));