import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import JusticeLeagueComponent from './components/justiceleague.component';

class MainApp extends Component{
    render(){
        return <div className='container'>
                <h1> Welcome to your life </h1>
                <hr/>
                <JusticeLeagueComponent/>
               </div>
    }
}


ReactDOM.render(<MainApp/>, document.getElementById("root"));