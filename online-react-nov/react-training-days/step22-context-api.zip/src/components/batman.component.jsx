import React, { Component } from 'react';
import SupermanComponent from './superman.component';

class BatmanComponent extends Component{
    render(){
        return <div style={ { border : "2px solid red", padding : "10px", margin:"10px"} }>
                <h1> Welcome to  Batman Component </h1>
                <SupermanComponent/>
              </div>
    }
}
export default BatmanComponent;