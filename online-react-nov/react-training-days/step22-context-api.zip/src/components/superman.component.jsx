import { Component } from "react";
import WonderWomenComponent from "./wonderwomen.component";


class SupermanComponent extends Component{
    render(){
        return <div style={ { border : "2px solid red", padding : "10px", margin:"10px"} }>
                <h1> Welcome to  Superman Component </h1>
                <WonderWomenComponent/>
              </div>
    }
} 

export default SupermanComponent;