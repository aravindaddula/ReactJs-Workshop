import React, { Component, useContext } from 'react';
import JusticeContext from '../contexts/hero.context';

/* class WonderWomenComponent extends Component{
    render(){
        return <div style={ { border : "2px solid red", padding : "10px", margin:"10px"} }>
                <h1> Welcome to  Wonder Women Component </h1>
                <JusticeContext.Consumer>{ 
                (value)=> <h2>Justice League Message : {value.message}</h2>
                }</JusticeContext.Consumer>
              </div>
    }
} */


let WonderWomenComponent = ()=> {
    let jleague = useContext( JusticeContext );

    return <div style={ { border : "2px solid red", padding : "10px", margin:"10px"} }>
                <h1> Welcome to  Wonder Women Component </h1>
                <h2>Justice League Message : {jleague.message}</h2>
              </div>

}
export default WonderWomenComponent;