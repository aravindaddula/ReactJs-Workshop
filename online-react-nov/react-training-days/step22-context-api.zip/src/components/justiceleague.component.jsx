import React, { Component } from 'react';
import JusticeContext from '../contexts/hero.context';
import BatmanComponent from './batman.component';

class JusticeLeagueComponent extends Component{
    ipRef = React.createRef();
    state = {
        message : '',
        version : 101
    }
    changeMessage = ()=>{
        this.setState({
            message : this.ipRef.current.value
        }, ()=> this.ipRef.current.value = '' );
    }
    render(){
        return <div style={ { border : "2px solid red", padding : "10px", margin:"10px"} }>
                <h1> Welcome to  Justice League Component </h1>
                <input ref={ this.ipRef }/>
                <button onClick={ this.changeMessage }>Send Message</button>
                <h2>Message is : { this.state.message }</h2>
                <JusticeContext.Provider value={ this.state }>
                    <BatmanComponent/>
                </JusticeContext.Provider>
              </div>
    }
}
export default JusticeLeagueComponent;