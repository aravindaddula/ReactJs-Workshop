import React from 'react';

const JusticeContext = React.createContext();

export default JusticeContext;
