const redux = require("redux");
const thunkMiddleWare = require("redux-thunk").default;
const axios = require("axios");

const createStore = redux.createStore;
const applyMiddleware = redux.applyMiddleware;
// action 
const AXIOS_USER_REQUEST = "AXIOS_USER_REQUEST";
const AXIOS_USER_SUCCESS = "AXIOS_USER_SUCCESS";
const AXIOS_USER_ERROR = "AXIOS_USER_ERROR";

// action creator
const fetchUsers = ()=>{
    return {
        type : AXIOS_USER_REQUEST
    }
}
const fetchUserSuccess = (users)=>{
    return {
        type : AXIOS_USER_SUCCESS,
        payload : users
    }
}
const fetchUserError = (error)=>{
    return {
        type : AXIOS_USER_ERROR,
        payload : error
    }
}
// initalValue
const initalState = {
    users : [],
    error : '',
    loading : false
}
// reducer
 const userReducer = (state = initalState, action)=>{
    switch(action.type){
        case AXIOS_USER_REQUEST : return{ 
            ...state, 
            loading : true }
        case AXIOS_USER_SUCCESS : return{ 
            ...state, 
            loading : false, 
            users : action.payload, 
            error : '' }
        case AXIOS_USER_ERROR : return{ 
            ...state, 
            loading : false, 
            users : [], 
            error : action.payload }
        default : return state
    }
 }

// middleware configuration
const thunkFetchusers = ()=>{
    return function( dispatch ){
        dispatch( fetchUsers() )
    }
};

const thunkAjaxResponse = ()=>{
    return function( dispatch ){
        axios.get("https://jsonplaceholder.typicode.com/users")
        .then((res)=>{
            dispatch( fetchUserSuccess( res.data ) )
        })
        .catch((err)=>{
            dispatch( fetchUserError(err) )
        })
    }
}

// store
const store = createStore( userReducer, applyMiddleware(thunkMiddleWare) );

// subscribe and unsubscribe
store.subscribe(()=>{
    console.log( store.getState() );
})

// functions from middleware that can be dispatched 
store.dispatch( thunkFetchusers() );
store.dispatch( thunkAjaxResponse() );
// 