const redux = require("redux");
const createStore = redux.createStore;
// action 
const ADD_HERO = "ADD_HERO";
const REMOVE_HERO = "REMOVE_HERO";

// action creator
let addHero = ()=>{
    return {
        type : ADD_HERO,
        info : "First Redux Action Creator"
    }
}
let removeHero = ()=>{
    return {
        type : REMOVE_HERO,
        info : "Second Redux Action Creator"
    }
}

// initial state
const initialState = {
    numberOfHeroes : 0
}

// reducer
const reducer = (state = initialState,action)=>{
    switch(action.type){
        case ADD_HERO : return{ numberOfHeroes : state.numberOfHeroes + 1 }
        case REMOVE_HERO : return{ numberOfHeroes : state.numberOfHeroes - 1 }
        default : return state
    }
}

// store
const store = createStore( reducer );

console.log("Initial Store values ",store.getState());

// subscribe and unsubscribe
const unsubscribe = store.subscribe(()=> console.log( store.getState() ))

// dispatch
store.dispatch( addHero() );
store.dispatch( addHero() );
store.dispatch( removeHero() );
store.dispatch( addHero() );
unsubscribe();
store.dispatch( addHero() );