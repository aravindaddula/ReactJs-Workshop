import { Component } from "react";

class ChildComp extends Component{
    render(){
        return <div>
                <h1> Child Component </h1>
                <h2>Message from parent is : { this.props.msg }</h2>
                <button onClick={ ()=> this.props.chp(10) }>Increase Parent Power</button>
                <br/>
                <input onInput={ (evt)=>{ this.props.chp(Number(evt.target.value)) }} min="10" max="80" step="5" type="range"/>
            </div>
    }
}

export default ChildComp;