import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import ChildComp from './components/childComp';

class MainApp extends Component{
    render(){
        return <div>
                <h1> Welcome to Ajax Example </h1>
                <ChildComp/>
            </div>
    }
}


ReactDOM.render(<MainApp/>, document.getElementById("root"));