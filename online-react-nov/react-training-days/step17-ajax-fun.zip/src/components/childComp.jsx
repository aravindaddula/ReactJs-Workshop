import React, { Component } from 'react';
import { fetchUrl } from 'fetch';

class ChildComp extends Component{
    state = {
        message : "",
        users : []
    }

    loadData = ()=>{
        fetchUrl("https://jsonplaceholder.typicode.com/user", (err, meta, data)=>{
            if(!err){
                this.setState({
                    users : JSON.parse(data)
                })
            }else{
                console.log("Error happened")
                // console.log(error);
                this.setState({
                    message : err+""
                })
            }
        })
    }

    componentDidMount(){
        // this.loadData();
    }
    
    render(){
        return <div>
                <h1> Child Comp </h1>
                <h2>Message is : { this.state.message }</h2>
                <button onClick={ this.loadData }>Get Data </button>
                <ol>
                {
                    this.state.users.map((user)=><li key={user.id}>{ user.name }</li>)
                }
                </ol>
               </div>
    }
}

export default ChildComp ;