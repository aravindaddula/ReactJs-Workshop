import React, { Component } from 'react';

class ChildComp extends Component{
    state = {
        power : 0,
        message : ""
    }
    arr = [];
    constructor(){
        super();
        console.log("ChildComp's was called");
       /*  this.state = {
            power : 5
        } */
    }
    static getDerivedStateFromProps(parentProps, currentState){
        console.log("ChildComp's getDerivedStateFromProps constructor was called");
        // return true;
        return {
            power : parentProps.power
        }
    }
    componentDidMount(){
        console.log("ChildComp's componentDidMount was called")
    }
    shouldComponentUpdate(){
        console.log("ChildComp's shouldComponentUpdate was called");
        return true;
    }
    getSnapshotBeforeUpdate(...args){
        console.log("Component's Props");
        console.log("Component's State");
        console.log("ChildComp's getSnapshotBeforeUpdate was called");
        return {
            info : args[1]
        }
    }
    componentDidUpdate(){
        console.log(arguments[0], arguments[1], arguments[2]);
        console.log("ChildComp's componentDidUpdate was called");
        this.arr.push(arguments[2]);
        console.log(this.arr);
    }
	componentWillUnmount(){
        console.log("ChildComp's componentWillUnmount was called")
    }
    render(){
        console.log("ChildComp's render was called")
        return <div>
                <h1> Child Comp </h1>
                <h2>Parent Power : { this.props.power }</h2>
                <h2>Personal Power : { this.state.power }</h2>
               </div>
    }
}

export default ChildComp ;