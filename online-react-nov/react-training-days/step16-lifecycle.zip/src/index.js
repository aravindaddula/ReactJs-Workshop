import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import ChildComp from './components/childComp';

class MainApp extends Component{
    state = {
        power : 0,
        version : 0
    }
    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
    render(){
        return <div className="container">
                <h1> LifeCycle Events </h1>
                <button onClick={ this.increasePower } className="btn btn-primary">Click to Increase Power</button>
                <hr/>
                { this.state.power <= 20 ? <ChildComp power={ this.state.power }/> : <h2> Child component removed </h2>}
              </div>
    }
}


ReactDOM.render(<MainApp version="100"/>, document.getElementById("root"));