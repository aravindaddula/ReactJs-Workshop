import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
    config = {
        power : 0
    };
    increasePower = ()=>{
        this.config.power = this.config.power + 1;
        console.log(this.config.power);
        this.forceUpdate();
    }
    render(){
        return <div>
                    <h1> Welcome to your life </h1>
                    <h2>Power is : { this.config.power }</h2>
                    <button onClick={ this.increasePower }>Click to Increase Power</button>
               </div>
    }
}


ReactDOM.render(<MainApp/>, document.getElementById("root"));