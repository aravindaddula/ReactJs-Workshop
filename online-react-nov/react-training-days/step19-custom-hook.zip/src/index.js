import { useState } from 'react';
import ReactDOM from 'react-dom';
import ArrayStateComp from './components/arrayChildComp';
import ChildComp from './components/childComp';
import ObjectStateComp from './components/objectChildComp';
import UseEffectComp from './components/useEffectComp';
import UseReducerComp from './components/useReducerComp';
import useShowHide from './hooks/useShowHide';
function MainApp(){
    let [version, updateVersion] = useState(100);
    let [show, toggleComp] = useState(true);
    let [toggleVal, callFun] = useShowHide();
    return <div className="container">
            <h1> Welcome to Hooks</h1>
            <ChildComp/>
            <ArrayStateComp/>
            <ObjectStateComp/>
            <hr/>
            <UseReducerComp/>
            <hr/>
            <button onClick={()=> updateVersion(version+10)}>Update Version </button>
            <button onClick={()=> toggleComp(!show)}> Show / Hide Comp </button>
            { toggleVal ? <UseEffectComp version={ version }/> : <h2>component is hidden</h2>}
            {/* <h2>{ toggleVal ? 'True' : 'False' }</h2> */}
            <button onClick={ callFun }>Click Me To Hide The Component</button>
        </div>
}
ReactDOM.render(<MainApp/>, document.getElementById("root"));