import { useEffect, useState } from "react";

function UseEffectComp(props){
    let [power, updatePower] = useState(0);
    useEffect(()=>{
        console.log("UseEffectComponent is mounted");
    },[]);
    useEffect(()=>{
        return ()=>{
            console.log("UseEffectComponent is unmounted");
        }
    },[]);
    useEffect(()=>{
        console.log("Power is updated ", power);
    },[power]);
    useEffect(()=>{
        console.log("Version is updated ", props.version);
    },[props.version]);
    return <div>
            <h1>Use Effect Component</h1>
            <h3>Power : { power }</h3>
            <h3>Version : { props.version }</h3>
            <button onClick={()=> updatePower(power + 1)}>Increase Power</button>
        </div>
};

export default UseEffectComp;