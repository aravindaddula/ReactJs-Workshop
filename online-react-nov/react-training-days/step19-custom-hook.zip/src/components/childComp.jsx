/*
class Components
function Components
class Pure Components
function Memo Components
*/

import { useState } from "react";
function ChildComp(){
    let [ power, setPower ] = useState(10);
    return <div>
            <h1> Child Comp </h1>
            <h2>Power : { power }</h2>
            <button onClick={ ()=>{  setPower( power = power+1 ) } }>Increase Powers</button>
            <button onClick={ ()=>{  setPower( power = power-1 ) } }>Decrease Powers</button>
           </div>
}
export default ChildComp ;