import { useRef, useState } from "react";

function ArrayStateComp(){
    let [avengers, addAvenger] = useState([]);
    let txtIp = useRef();
    return <div>
        <h2>Array State Component</h2>
       <input type="text" onBlur={(evt)=>{ 
            // let heros = avengers;
            // heros.push(evt.target.value);
            // addAvenger([heros]);

            addAvenger([...avengers, evt.target.value]);
            evt.target.value = "";

         }} />
       {/*  
       <input ref={ txtIp } type="text" />
        <button onClick={ ()=>{
            addAvenger([...avengers, txtIp.current.value]);
            txtIp.current.value = "";
        }}>Add Avenger</button> 
        */}
        <ol>
            {
                avengers.map((avenger, idx)=> <li key={ idx }>{ avenger }</li>)
            }
        </ol>
    </div>
}

export default ArrayStateComp;