import { useState } from "react";

let useShowHide = (initVal = true)=>{
    // return "Hello There";
    // return msg.toUpperCase();
    const [state, setState] = useState(initVal);
    let toggleFun = ()=>{
        // console.log("toggle fun was called");
        setState(!state);
    }
    return [state, toggleFun];
}

export default useShowHide;