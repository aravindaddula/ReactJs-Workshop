import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
    state = {
        power : 4
    }
    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
    decreasePower = ()=>{
        this.setState({
            power : this.state.power - 1
        })
    }
    render(){
        /* if(this.state.power < 5){
            return <div>
                    <h1> Power is less than 5 </h1>
                </div>
        }else{
            return <div>
                    <h1> Power is more than 5 </h1>
                </div>
        } */

        return <div>
                    <h1> Welcome to your life </h1>
                    <h2> Power : { this.state.power }</h2>
                    <h2> Hero is { this.state.power < 5 ? "weak" : "strong" } </h2>
                    { this.state.power < 5 && <h2> Hero is WEAK </h2> } 
                    { this.state.power > 6 && <h2> Hero is STRONG </h2> }

                    <button onClick={ this.increasePower }>Increase Power</button>
                    <button onClick={ this.decreasePower }>Decrease Power</button>
                </div>
    }
}


ReactDOM.render(<MainApp/>, document.getElementById("root"));