import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class MainApp extends Component{
    state = {
        power : 0
    }
    increasePower = ()=>{
      /*   this.setState({
            power : this.state.power + 1
        });
        console.log(this.state.power); */
        this.setState(function(currentState, currentProps){
            console.log(currentProps);
            return {
                power : currentState.power + 1
            }
        }, function(){
            console.log(this.state.power);
        });
    }
    render(){
        return <div>
                <h1> Welcome to your life </h1>
                <h2>Power is : { this.state.power }</h2>
                <button onClick={ this.increasePower }>Increase Power</button>
               </div>
    }
}


ReactDOM.render(<MainApp title="hello"/>, document.getElementById("root"));