import { useReducer, useState } from "react"

function UseReducerComp(){
   /*  let [userfirstname, updateUserfirstName] = useState("");
       let [userlastname, updateUserlastName] = useState(""); */

    let reducerFun = (user, action)=>{
        switch(action.type){
            case "UPDATEFIRSTNAME" : return {...user, firstname : action.payload }
            case "UPDATELASTNAME" : return {...user, lastname : action.payload }
            case "UPDATETITLE" : return {...user, title : action.payload }
            case "ADDMOVIE" : return { movies : [...user.movies, action.payload] }
            default : return user
        }
    }

    let [store, dispatch] = useReducer(reducerFun,{title : "default title", firstname : 'default firstname', lastname : 'default lastname', movies : []})
    return <div>
            <h2>Object UseState </h2>
            <h3>Title : { store.title } <br/> First Name : { store.firstname } <br/> Last Name : { store.lastname } </h3>
            <ul>{ store.movies.map((movie,idx)=><li key={ idx }>{movie}</li>)}</ul>
{/*         <input type="text" onChange={ evt=> updateUserfirstName( evt.target.value )} />
            <input type="text" onChange={ evt=> updateUserlastName( evt.target.value  )} /> */}
            First Name : <input type="text" onChange={ (evt)=> dispatch({ type : "UPDATEFIRSTNAME", payload : evt.target.value })} />
            <br/>
            Last Name : <input type="text" onChange={ (evt)=> dispatch({ type : "UPDATELASTNAME", payload : evt.target.value })} />
            <br/>
            Title : <input type="text" onChange={ (evt)=> dispatch({ type : "UPDATETITLE", payload : evt.target.value })} />
            <br/>
            Movie : <input type="text" onBlur={ (evt)=> dispatch({ type : "ADDMOVIE", payload : evt.target.value })} />
          </div>
}

export default UseReducerComp;