import { useState } from "react"

function ObjectStateComp(){
   // let [user, updateUserInfo] = useState({ firstname : "Bruce", lastname : "Wayne" });
    let [userfirstname, updateUserfirstName] = useState("");
    let [userlastname, updateUserlastName] = useState("");

    return <div>
            <h2>Object UseState </h2>
           {/*  <h3>First Name : { user.firstname } <br/> Last Name : { user.lastname } </h3> */}
           {/*  <input type="text" onChange={ evt=> updateUserInfo({...user, firstname : evt.target.value })} />
            <input type="text" onChange={ evt=> updateUserInfo({...user, lastname : evt.target.value })} /> */}
            <h3>First Name : { userfirstname } <br/> Last Name : { userlastname } </h3>
            <input type="text" onChange={ evt=> updateUserfirstName( evt.target.value )} />
            <input type="text" onChange={ evt=> updateUserlastName( evt.target.value  )} />
          </div>
}

export default ObjectStateComp;