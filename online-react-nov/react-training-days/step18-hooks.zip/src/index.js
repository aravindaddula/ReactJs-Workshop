import { useState } from 'react';
import ReactDOM from 'react-dom';
import ArrayStateComp from './components/arrayChildComp';
import ChildComp from './components/childComp';
import ObjectStateComp from './components/objectChildComp';
import UseEffectComp from './components/useEffectComp';
import UseReducerComp from './components/useReducerComp';
function MainApp(){
    let [version, updateVersion] = useState(100);
    let [show, toggleComp] = useState(true);
    return <div className="container">
            <h1> Welcome to Hooks</h1>
            <ChildComp/>
            <ArrayStateComp/>
            <ObjectStateComp/>
            <hr/>
            <UseReducerComp/>
            <hr/>
            <button onClick={()=> updateVersion(version+10)}>Update Version </button>
            <button onClick={()=> toggleComp(!show)}> Show / Hide Comp </button>
            { show ? <UseEffectComp version={ version }/> : <h2>component is hidden</h2>}
        </div>
}
ReactDOM.render(<MainApp/>, document.getElementById("root"));