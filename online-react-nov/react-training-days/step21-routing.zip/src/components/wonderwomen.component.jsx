import React, { Component } from 'react';

class WonderWomenComponent extends Component{
    render(){
        return <div>
                <h1> Welcome to  Wonder Women Component </h1>
              </div>
    }
}
export default WonderWomenComponent;