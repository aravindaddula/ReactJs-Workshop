import React, { Component } from 'react';

class NotFoundComponent extends Component{
    render(){
        return <div>
                <h1> 404 : Requested Page NotFound Component </h1>
              </div>
    }
}
export default NotFoundComponent;