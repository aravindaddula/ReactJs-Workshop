import React, { Component } from 'react';

class JusticeLeagueComponent extends Component{
    render(){
        return <div>
                <h1> Justice League Hero Home Page </h1>
              </div>
    }
}
export default JusticeLeagueComponent;