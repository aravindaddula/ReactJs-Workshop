import { useParams } from 'react-router-dom';

/* class SupermanComponent extends Component{
    render(){
        return <div>
                <h1> Welcome to  Superman Component </h1>
              </div>
    }
} */

let SupermanComponent = ()=>{
    let {movie} = useParams();
    return <div>
                <h1> Welcome to  Superman Component </h1>
                <h2> Selected Movie is : { movie || 'not yet set' }</h2>
           </div>
}
export default SupermanComponent;