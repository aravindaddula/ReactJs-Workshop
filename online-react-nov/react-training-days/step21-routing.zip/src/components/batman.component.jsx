import React, { Component } from 'react';

class BatmanComponent extends Component{
    render(){
        return <div>
                <h1> Welcome to  Batman Component </h1>
              </div>
    }
}
export default BatmanComponent;