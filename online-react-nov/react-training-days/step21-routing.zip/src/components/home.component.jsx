import React, { Component } from 'react';
import { BrowserRouter, Link, NavLink, Route, Routes } from 'react-router-dom';
import BatmanComponent from './batman.component';
import JusticeLeagueComponent from './justice.league.component';
import NotFoundComponent from './notfound.component';
import SupermanComponent from './superman.component';
import WonderWomenComponent from './wonderwomen.component';
import "./mystyle.css";

class HomeComponent extends Component{
    state = {
        selectedMovie : ''
    }
    render(){
        return <div>
                <input type="text" onBlur={(evt)=> this.setState({ selectedMovie : evt.target.value})} /> {'Selected Movie : '+ this.state.selectedMovie }
                <BrowserRouter>
                {/* <ul>
                    <li> <a href='/'> Home </a> </li>
                    <li> <a href='/batman'> Batman </a> </li>
                    <li> <a href='/superman'> Superman </a> </li>
                </ul> */}
                   {/*  <ul>
                        <li> <Link to="/">Home</Link> </li>
                        <li> <Link to="/batman">Batman</Link> </li>
                        <li> <Link to="/superman">Superman</Link> </li>
                        <li> <Link to="/wonderwomen">Wonder Women</Link> </li>
                        <li> <Link to="/cyborg">Cyborg</Link> </li>
                        <li> <Link to="/aquaman">Aquaman</Link> </li>
                    </ul> */}
                     <ul>
                        <li> <NavLink className={({isActive})=> isActive ? 'boxer' : 'box' } to="/">Home</NavLink> </li>
                        <li> <NavLink className={({isActive})=> isActive ? 'boxer' : 'box' } to="/batman">Batman</NavLink> </li>
                        <li> <NavLink className={({isActive})=> isActive ? 'boxer' : 'box' } to={'/superman/'+this.state.selectedMovie}>Superman</NavLink> </li>
                        <li> <NavLink className={({isActive})=> isActive ? 'boxer' : 'box' } to="/wonderwomen">Wonder Women</NavLink> </li>
                        <li> <NavLink className={({isActive})=> isActive ? 'boxer' : 'box' } to="/cyborg">Cyborg</NavLink> </li>
                        <li> <NavLink className={({isActive})=> isActive ? 'boxer' : 'box' } to="/aquaman">Aquaman</NavLink> </li>
                    </ul>
                    <Routes>
                        <Route path="/" element={<JusticeLeagueComponent/>}/>
                        <Route path="/batman" element={<BatmanComponent/>}/>
                        <Route path="/superman/:movie" element={<SupermanComponent/>}/>
                        <Route path="/superman" element={<SupermanComponent/>}/>
                        <Route path="/wonderwomen" element={<WonderWomenComponent/>}/>
                        <Route path="*" element={<NotFoundComponent/>}/>
                    </Routes>
                </BrowserRouter>
              </div>
    }
}
export default HomeComponent;