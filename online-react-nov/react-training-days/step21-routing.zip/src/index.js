import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import HomeComponent from './components/home.component';

class MainApp extends Component{
    render(){
        return <div className='container'>
                <h1> Welcome to your life </h1>
                <hr/>
                <HomeComponent/>
               </div>
    }
}


ReactDOM.render(<MainApp/>, document.getElementById("root"));