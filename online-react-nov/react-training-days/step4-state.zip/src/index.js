import React, { Component } from 'react';
import ReactDOM from 'react-dom';

class ChildApp extends Component{
    state = {
        power : 0
    }
    render(){
        return <div>
                <h1> Child Component </h1>
                <h2>Power is { this.state.power }</h2>
                <button onClick={()=>{ this.setState({ power : this.state.power + 1 }) }}>Increase Power</button>
            </div>
    }
}
class MainApp extends Component{
    render(){
        return <div>
                <h1> Welcome to your life </h1>
                <hr/>
                <ChildApp/>
            </div>
    }
}


ReactDOM.render(<MainApp/>, document.getElementById("root"));