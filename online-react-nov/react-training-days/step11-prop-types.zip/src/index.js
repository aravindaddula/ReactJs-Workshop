import React, { Component } from 'react';
import ReactDOM from 'react-dom';
import ChildComp from './components/child.component';

class MainApp extends Component{
    state = {
        power : 0,
        version : 0,
        title : "default value"
    }
    increasePower = ()=>{
        this.setState({
            power : this.state.power + 1
        })
    }
    increaseVersion = ()=>{
        this.setState({
            version : this.state.version + 1
        })
    }
    render(){
        return <div>
                <h1> Welcome to your life </h1>
                <h2>Power : { this.state.power }</h2>
                <h2>Version : { this.state.version }</h2>
                <button onClick={ this.increasePower }>Increase Power</button>
                <button onClick={ this.increaseVersion }>Increase Version</button>
                <hr/>
                <ChildComp title={ this.state.title } version={this.state.version} power={ this.state.power }/>
                <ChildComp version={this.state.version} power={ this.state.power }/>
                <ChildComp power={ this.state.power }/>
                <ChildComp />
            </div>
    }
}


ReactDOM.render(<MainApp/>, document.getElementById("root"));