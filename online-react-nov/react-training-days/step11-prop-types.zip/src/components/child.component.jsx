import { Component } from "react";
import PropTypes from "prop-types";

class ChildComp extends Component{
   /*  static defaultProps = {
        power : 100,
        version : 100,
        title : 'placeholder title '
    } */
    static propTypes = {
        power : PropTypes.number.isRequired,
        version : PropTypes.number.isRequired,
        title : PropTypes.string.isRequired
    };
    render(){
        return <div>
                <h1> Child Component </h1>
               {/*  <h2>Power : { this.props.power || 'power is missing' }</h2>
                <h2>Version : { this.props.version || 'version is missing' }</h2>
                <h2>Title : { this.props.title || 'title is missing' }</h2> */}
                <h2>Power : { this.props.power }</h2>
                <h2>Version : { this.props.version }</h2>
                <h2>Title : { this.props.title }</h2>
            </div>
    }
}

/* ChildComp.defaultProps = {
    power : 100,
    version : 100,
    title : 'placeholder title '
} */

export default ChildComp;