import { Component } from "react";

class FormComp extends Component{
    state = {
        username : '',
        userage : 0,
        userNameError : '',
        userAgeError : ''
    }
    nameChangeHandler = (evt)=>{
        this.setState({
            username : evt.target.value
        })
    }
    ageChangeHandler = (evt)=>{
        this.setState({
            userage : evt.target.value
        })
    }
    submitHandler = (evt)=>{
        evt.preventDefault();
        if( this.state.username === '' && this.state.userage === 0){
            this.setState({
                userNameError : 'Please fill your name',
                userAgeError : ' Please fill your age'
            })
        }else{
            if(this.state.userage < 18){
                this.setState({
                    userAgeError : 'You are too young to join us'
                })
            }else if(this.state.userage > 100){
                this.setState({
                    userAgeError : 'You are too old to join us'
                })
            }else{
                this.setState({
                    userNameError : '',
                    userAgeError : ''
                });
                evt.target.submit();
            }
        }
    }
    render(){
        return <div>
                <form action="#" onSubmit={ this.submitHandler }>
                    <div className="mb-3">
                        <label htmlFor="uname" className="form-label">User Name : </label>
                        <input name="username" onChange={ this.nameChangeHandler } type="text" className="form-control" id="uname" value={ this.state.username }/>
                        <div className="text-danger">{ this.state.userNameError }</div>
                    </div>
                    <div className="mb-3">
                        <label htmlFor="uage" className="form-label">User Age</label>
                        <input name="userage" onChange={ this.ageChangeHandler } type="number" className="form-control" id="uage"  value={ this.state.userage }/>
                        <div className="text-danger">{ this.state.userAgeError }</div>
                    </div>
                    <button type="submit" className="btn btn-primary">Submit</button>
                </form>
                <hr />
                <ul>
                    <li>User Name : { this.state.username }</li>
                    <li>User Age : { this.state.userage }</li>
                </ul>
        </div>
    }
}

export default FormComp;